package com.company;

public class Bank2 {
}
