package com.company;
import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) {
        Connection connection = null;
        Statement st = null;
        ResultSet rs = null;

        ConnectDB obj_ConnectDB = new ConnectDB();
        connection = obj_ConnectDB.get_connection();
Menu menu =new Menu();
menu.StartFunc();
        try {

            //String queryCreate = "CREATE TABLE Bank(User_ID INTEGER,bank_account int,number_card int,CVV int, FOREIGN KEY (User_ID) references login(USER_ID))";
            //String queryCreate="CREATE TABLE Registration(User_ID SERIAL PRIMARY KEY,Name varchar(200),surname VARCHAR(200),username VARCHAR(20),password INT(10),email VARCHAR(100))";
//            String queryCreate="CREATE TABLE Registration(User_ID SERIAL PRIMARY KEY,Name varchar(200),surname VARCHAR(200),username VARCHAR(20),password INT(10),email VARCHAR(100))";

            //            String queryCreate
//            String queryCreate
//            String queryCreate
            //String queryCreate ="CREATE TABLE Car(car_id INTEGER PRIMARY KEY,brand varchar(200),color varchar(200),price int)";
//            //String queryCreate ="CREATE TABLE Landlord(client_id INTEGER PRIMARY KEY,client_name varchar(200),city varchar(200),bank int)";
//            // String queryCreate ="CREATE TABLE Order_details(client_id int,car_id int,FOREIGN KEY (client_id)\n" +
//            //  "        REFERENCES Landlord(client_id),FOREIGN KEY(car_id)REFERENCES Car(car_id))";
            //String queryInsert = "INSERT INTO employee(name, address) VALUES ('Abai', 'Pekin')";
            //String queryUpdate = "UPDATE employee SET name = 'John' where empno=2";
            //String queryDelete = "DELETE from employee where empno=4";
//
//            PreparedStatement pr = connection.prepareStatement("INSERT INTO employee(name, address) VALUES (?,?)");
//
//            String name = "Aman";
//            String address = "Pavlodar";
//
//            pr.setString(1, name);
//            pr.setString(2, address);
//
//            pr.executeUpdate();
//
          st = connection.createStatement();
//            //st.executeUpdate(queryDelete);
//
//            String querySelect = "SELECT * FROM employee";
//            rs = st.executeQuery(querySelect);
//
//            while(rs.next()) {
//                System.out.println(rs.getInt(1));
//                System.out.println(rs.getString(2));
//                System.out.println(rs.getString(3));
//            }
//            st.executeUpdate(queryCreate);
            System.out.println("Done");

            st.close();
            connection.close();


        } catch (Exception e) {
            System.out.println(e);
        }

    }
}

